Process No.	Process Size	Block No.
1 		 212 		 2
2 		 417 		 5
3 		 112 		 1
4 		 426 		 Not Allocated

#In the output, the "Block No." column shows the block number to which the process has been allocated. 
#If a process is not allocated to any block, the "Block No." value is "Not Allocated".
