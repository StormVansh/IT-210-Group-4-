Best Fit Allocation:
Process No.	Process Size	Block No.
1 		 212 		 2
2 		 417 		 5
3 		 112 		 1
4 		 426 		 Not Allocated
